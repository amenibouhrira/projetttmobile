package com.example.projetmobile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class introActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intro);
    }
    public void home(View view){
        Intent retour_intent=new Intent(this,homeActivity.class);
        startActivity(retour_intent);
    }
    public void logger(View view) {
        Intent intentlog=new Intent(introActivity.this,loginActivity.class);
        startActivity(intentlog);
    }
    public void inscrire(View view) {
        Intent intentins=new Intent(introActivity.this,inscActivity.class);
        startActivity(intentins);
    }
    public void reserver(View view) {
        Intent intentres=new Intent(introActivity.this,reserverActivity.class);
        startActivity(intentres);
    }
    public void abonner(View view) {
        Intent intentabn=new Intent(introActivity.this,abonnerActivity.class);
        startActivity(intentabn);
    }
}